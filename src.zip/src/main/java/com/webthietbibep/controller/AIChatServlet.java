package com.webthietbibep.controller;

import com.webthietbibep.dao.ProductDAO;
import com.webthietbibep.dao.CategoryDAO;
import com.webthietbibep.dao.BrandDAO;
import com.webthietbibep.model.Product;
import com.webthietbibep.model.Category;
import com.webthietbibep.model.Brand;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.*;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

@WebServlet(name = "AIChatServlet", urlPatterns = {"/ai-chat"})
public class AIChatServlet extends HttpServlet {

    private String getApiKey() {
        String key = System.getenv("GEMINI_API_KEY");
        if (key == null || key.isBlank()) {
            key = getServletContext().getInitParameter("geminiApiKey");
        }
        return (key != null) ? key.trim() : null;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json; charset=UTF-8");

        String mode    = null;
        String message = null;
        String history = null;

        String contentType = request.getContentType();
        if (contentType != null && contentType.contains("application/x-www-form-urlencoded")) {
            String body = request.getReader().lines().collect(Collectors.joining());
            for (String pair : body.split("&")) {
                String[] kv = pair.split("=", 2);
                if (kv.length == 2) {
                    String key = java.net.URLDecoder.decode(kv[0], StandardCharsets.UTF_8);
                    String val = java.net.URLDecoder.decode(kv[1], StandardCharsets.UTF_8);
                    switch (key) {
                        case "mode"    -> mode    = val;
                        case "message" -> message = val;
                        case "history" -> history = val;
                    }
                }
            }
        } else {
            mode    = request.getParameter("mode");
            message = request.getParameter("message");
            history = request.getParameter("history");
        }

        System.out.println("[AIChatServlet] mode=" + mode + " | message=[" + message + "]");

        if (message == null || message.isBlank()) {
            response.getWriter().write("{\"error\":\"Tin nhắn không được để trống\"}");
            return;
        }

        if ("admin".equals(mode)) {
            HttpSession session = request.getSession(false);
            Object user = (session != null) ? session.getAttribute("user") : null;
            if (user == null) {
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.getWriter().write("{\"error\":\"Bạn cần đăng nhập để sử dụng tính năng này\"}");
                return;
            }
        }

        String systemPrompt = "admin".equals(mode) ? buildAdminPrompt() : buildUserPrompt();
        String aiReply = callGeminiAPI(systemPrompt, message, history);

        response.getWriter().write("{\"reply\":" + escapeJson(aiReply) + "}");
    }

    private String buildAdminPrompt() {
        StringBuilder sb = new StringBuilder();
        sb.append("Bạn là trợ lý quản trị thông minh cho website bán thiết bị bếp 'WebThietBiBep'. ");
        sb.append("Hỗ trợ admin trong: quản lý sản phẩm, đơn hàng, tồn kho, voucher, báo cáo doanh thu, marketing. ");
        sb.append("Trả lời ngắn gọn, chuyên nghiệp bằng tiếng Việt. ");
        try {
            int total = new ProductDAO().countAll();
            sb.append("Hệ thống hiện có ").append(total).append(" sản phẩm. ");
        } catch (Exception ignored) {}
        return sb.toString();
    }

    private String buildUserPrompt() {
        StringBuilder sb = new StringBuilder();
        sb.append("Bạn là chuyên viên tư vấn sản phẩm thân thiện của cửa hàng thiết bị bếp 'WebThietBiBep'. ");
        sb.append("Giúp khách hàng tìm sản phẩm phù hợp với nhu cầu và ngân sách. ");
        sb.append("Luôn hỏi thêm về: nhu cầu, ngân sách, thương hiệu ưa thích. ");
        sb.append("Trả lời bằng tiếng Việt, thân thiện, nhiệt tình. ");

        try {
            List<Category> cats = new CategoryDAO().getAll();
            if (!cats.isEmpty()) {
                sb.append("Danh mục sản phẩm: ");
                cats.forEach(c -> sb.append(c.getCategory_name()).append(", "));
                sb.append(". ");
            }
        } catch (Exception ignored) {}

        try {
            List<Brand> brands = new BrandDAO().getAll();
            if (!brands.isEmpty()) {
                sb.append("Thương hiệu: ");
                brands.forEach(b -> sb.append(b.getBrand_name()).append(", "));
                sb.append(". ");
            }
        } catch (Exception ignored) {}

        try {
            List<Product> best = new ProductDAO().getBestSellers();
            if (!best.isEmpty()) {
                NumberFormat vn = NumberFormat.getInstance(new Locale("vi", "VN"));
                sb.append("Sản phẩm bán chạy: ");
                best.forEach(p -> sb.append(p.getProduct_name())
                        .append(" (").append(vn.format(p.getPrice())).append("đ), "));
                sb.append(". ");
            }
        } catch (Exception ignored) {}

        return sb.toString();
    }

    private String callGeminiAPI(String systemPrompt, String userMessage, String historyJson)
            throws IOException {

        // 1. Gắn cứng (hardcode) API Key để không bị lỗi không tìm thấy cấu hình
        String apiKey = "AQ.Ab8RN6ItR5qNutF3v6THHSgtFofSpMXEMv9RcQiu21s7eBF6ig".trim();

        // 2. Đóng gói câu hỏi của người dùng
        StringBuilder contentsArray = new StringBuilder();
        contentsArray.append("{\"role\":\"user\",\"parts\":[{\"text\":").append(escapeJson(userMessage)).append("}]}");

        // 3. Đóng gói toàn bộ payload (bao gồm cả system prompt)
        String body = "{"
                + "\"contents\":[" + contentsArray + "],"
                + "\"systemInstruction\":{\"parts\":[{\"text\":" + escapeJson(systemPrompt) + "}]},"
                + "\"generationConfig\":{\"maxOutputTokens\":1024}"
                + "}";

        // 4. URL gọi lên Google Gemini (dùng model gemini-1.5-flash)
        String endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + apiKey;

        System.out.println("[AIChatServlet] Đang gửi yêu cầu lên Gemini...");

        // 5. Mở kết nối HTTP
        URL url = new URL(endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000); // Đợi kết nối 15s
        conn.setReadTimeout(30000);    // Đợi AI trả lời 30s

        // 6. Gửi body (JSON) đi
        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }

        // 7. Nhận phản hồi
        int status = conn.getResponseCode();
        InputStream is = (status == 200) ? conn.getInputStream() : conn.getErrorStream();
        String responseStr;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            responseStr = br.lines().collect(Collectors.joining());
        }

        System.out.println("[AIChatServlet] Gemini API HTTP Status = " + status);

        // 8. Nếu không thành công (khác 200), in lỗi ra console để dễ sửa
        if (status != 200) {
            System.err.println("[AIChatServlet] LỖI CHI TIẾT TỪ GOOGLE: " + responseStr);
            return "⚠️ Lỗi kết nối AI (HTTP " + status + "). Vui lòng kiểm tra console của Server.";
        }

        // 9. Nếu thành công, bóc tách text AI trả về
        return extractGeminiText(responseStr);
    }

    private String extractGeminiText(String json) {
        try {
            int idx = json.indexOf("\"text\":");
            if (idx == -1) return "Không nhận được phản hồi từ AI.";
            int start = json.indexOf("\"", idx + 7) + 1;
            int end = start;
            boolean esc = false;
            while (end < json.length()) {
                char c = json.charAt(end);
                if (esc) { esc = false; end++; continue; }
                if (c == '\\') { esc = true; end++; continue; }
                if (c == '"') break;
                end++;
            }
            return json.substring(start, end)
                    .replace("\\n", "\n").replace("\\t", "\t")
                    .replace("\\\"", "\"").replace("\\\\", "\\")
                    .replace("\\/", "/");
        } catch (Exception e) {
            return "Có lỗi xử lý phản hồi từ AI.";
        }
    }

    private String escapeJson(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"'  -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default   -> sb.append(c);
            }
        }
        return sb.append("\"").toString();
    }
}